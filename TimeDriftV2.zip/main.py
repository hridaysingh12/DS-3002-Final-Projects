# -*- coding: utf-8 -*-
"""
Created on Mon May  2 11:32:19 2022

@author: hrida
"""

import os
import requests
import json
import schedule
import datetime
import time
import threading
import sqlite3
import statistics as stats
import numpy as np
import pandas as pd



info_data = []

ticker =0
sql_table_created = 0
if sql_table_created ==0:
    conn = sqlite3.connect('ds_3002_api_v10.db', check_same_thread=False)
    cur = conn.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS ds3002data_v10( 
       factor INT,
       pi FLOAT,
       time VARCHAR PRIMARY KEY);
    """)

    conn.commit() #commits changes
    sql_table_created =1


def get_data():
  response = requests.get("https://4feaquhyai.execute-api.us-east-1.amazonaws.com/api/pi")
  json_data = json.loads(response.text)
  data = (json_data["factor"], json_data["pi"], json_data["time"])
  return data
  
def job1():
  if sql_table_created ==1:
    # global cur
    cur.execute("INSERT INTO ds3002data_v10 VALUES(?, ?, ?);", get_data())
    # global conn
    conn.commit()

def job2():
  global ticker
  ticker+=1
  # now = datetime.datetime.now()
  print(ticker)
  if ticker>=60:
    conn.close()
  

def run_threaded(job_func):
  job_thread = threading.Thread(target=job_func)
  job_thread.start()

update_freq = 60

schedule.every(update_freq).seconds.do(run_threaded, get_data)
schedule.every(update_freq).seconds.do(run_threaded, job1)
schedule.every(update_freq).seconds.do(run_threaded, job2)


while True and ticker <60:
    schedule.run_pending()
    # time.sleep(1)

