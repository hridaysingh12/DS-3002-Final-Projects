import discord
import os
import requests
import json
import random
from replit import db
from keep_alive import keep_alive
import time

client = discord.Client()

question_words = ["question"]


if "responding" not in db.keys():
  db["responding"] = True

def get_question():
  response = requests.get("https://jservice.io/api/random")
  
  json_data = json.loads(response.text)
  global question
  question = json_data[0]['question']
  global category
  category = json_data[0]["category"]["title"]
  global answer
  answer = json_data[0]['answer']
  global points
  points = int(json_data[0]["value"])
  return(question)



@client.event
async def on_ready():
  print('We have logged in as {0.user}'.format(client))


@client.event
async def on_message(message):
  if message.author == client.user:
    return

  msg = message.content

  if msg.startswith('$help') or msg.lower().strip() == "help":
    reply = "Type 'Give me a question' to get a trivia question. Type 'clue' if you need a hint, and when the timer runs out, type 'answer' to get the answer. You will have 10 seconds to think before an answer is given."
    await message.channel.send(reply)
    

  
  if msg.startswith('$trivia'):
    question = get_question()
    # await message.channel.send("Category: "+ category)
    await message.channel.send(question)
    for i in range(10,0,-1):
        await message.channel.send(str(i))
        time.sleep(1)
    # await message.channel.send(countdown)
    await message.channel.send(answer)

  for word in msg.split():
    if word.lower() in question_words:
      question = get_question()
      # await message.channel.send("Category: "+ category)
      await message.channel.send(question)
      for i in range(10,0,-1):
        await message.channel.send(str(i))
        time.sleep(1)
      # await message.channel.send(countdown)
      # await message.channel.send(answer)

  for word in msg.split():
      if word.lower() in ["answer", "solution", "a"]:
        # question = get_question()
        try:
          await message.channel.send(answer)
          # category = "n/a"
        except:
          await message.channel.send("No question asked")

          
          

  for word in msg.split():
    if word.lower() in ["clue","category","hint"]:
      # question = get_question()
      try:
        await message.channel.send("Category: "+ category)
        # category = "n/a"
      except:
        await message.channel.send("No question asked")
     


  if msg.startswith("$responding"):
    value = msg.split("$responding ",1)[1]

    if value.lower() == "true":
      db["responding"] = True
      await message.channel.send("Responding is on.")
    else:
      db["responding"] = False
      await message.channel.send("Responding is off.")

keep_alive()
client.run(os.getenv('TOKEN'))